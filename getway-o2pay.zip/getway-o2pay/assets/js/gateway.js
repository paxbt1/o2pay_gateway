

jQuery(document).ready(function ($) {
    // مقدار زمان نهایی از data-time
    let endTime = parseInt($('#time-expiration').data('time'), 10);

    function updateTimer() {
        // زمان فعلی
        let currentTime = Math.floor(Date.now() / 1000); // تبدیل به ثانیه
        let remainingTime = endTime - currentTime;

        if (remainingTime <= 0) {
            clearInterval(interval);

            // ریدایرکت به صفحه تسویه‌حساب
            window.location.href = '/checkout';
            return;
        }

        // تبدیل به دقیقه و ثانیه
        let minutes = Math.floor(remainingTime / 60);
        let seconds = remainingTime % 60;

        // نمایش مقادیر
        $('#time-expiration .min').text(minutes.toString().padStart(2, '0'));
        $('#time-expiration .sec').text(seconds.toString().padStart(2, '0'));
    }

    // اجرای اولیه تایمر
    updateTimer();

    // به‌روزرسانی هر ثانیه
    let interval = setInterval(updateTimer, 1000);
});


jQuery(document).ready(function($) {
    // محدود کردن مقدار ورودی در amount_pay
    $('#amount_pay').on('input', function() {
        const maxAmount = parseInt($(this).attr('max')); // مقدار max از attribute فیلد
        let currentValue = parseInt($(this).val().replace(/,/g, '')); // مقدار فعلی ورودی (حذف کاما برای محاسبه)

        if (isNaN(currentValue) || currentValue < 0) {
            currentValue = 0; // جلوگیری از مقدار منفی یا مقدار نامعتبر
        }

        if (currentValue > maxAmount) {
            currentValue = maxAmount; // اگر مقدار وارد شده از max بیشتر باشد، مقدار به max محدود شود
        }

        $(this).val(formatNumber(currentValue)); // فرمت قیمت با جداکننده سه‌رقمی
        calculateDifference(); // محاسبه مابه‌تفاوت
    });

    // وقتی کاربر کل اعتبار کیف پول را انتخاب کند
    $('input[name="total-pay"]').on('change', function() {
        if ($(this).is(':checked')) {
            const maxAmount = parseInt($('#amount_pay').attr('max'));
            $('#amount_pay').val(formatNumber(maxAmount)).prop('disabled', true); // فیلد amount_pay غیرفعال شود
        } else {
            $('#amount_pay').prop('disabled', false); // فیلد amount_pay دوباره فعال شود
        }
        calculateDifference(); // محاسبه مابه‌تفاوت
    });

    // محاسبه مابه‌تفاوت
    function calculateDifference() {
        const priceTotal = parseInt($('#price_total').val()); // مقدار کل
        const amountPay = parseInt($('#amount_pay').val().replace(/,/g, '')) || 0; // مقدار وارد شده در فیلد amount_pay
        const difference = priceTotal - amountPay; // محاسبه مابه‌تفاوت

        $('.value-pay-remained').text(formatNumber(difference >= 0 ? difference : 0)); // نمایش مابه‌تفاوت با فرمت قیمت
    }

    // تابع فرمت قیمت
    function formatNumber(number) {
        return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); // افزودن کاما بین هر سه رقم
    }

    // محاسبه اولیه مابه‌تفاوت
    calculateDifference();
});
