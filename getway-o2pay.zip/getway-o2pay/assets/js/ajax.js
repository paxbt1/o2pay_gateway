jQuery(document).ready(function($) {
    $(document).on('click', '#send_otp_second_code', function() {
        const national_id = $('#national_id').attr('data-nationalid');
        const amount_pay = parseInt($('input#amount_pay').val().replace(/,/g, ''), 10);
        const tracking_code = $('input#tracking_code').val();
        const order_id = $('#custom-payment-page').data('order');
        const $button = $(this); // ذخیره مرجع دکمه برای تغییر متن
        // console.log(tracking_code);
        if (!amount_pay || amount_pay == 0) {
            alert('مبلغ پرداختی با اعتبار کیف پول');
            return;
        }
    
        // غیرفعال کردن ورودی amount_pay
        $('input#amount_pay').prop('disabled', true);
    
        $.ajax({
            url: ajax_object.ajaxurl,
            method: 'POST',
            dataType: 'json',
            data: {
                action: 'send_otp_second_code',
                national_id: national_id,
                amount_pay: amount_pay,
                order_id: order_id,
                tracking_code: tracking_code,
            },
            success: function(response) {
                if (response.success) {
                    $button.attr('id', 'resend_otp_second_code'); // بازگرداندن متن اصلی
    
                    // ایجاد تایمر 2 دقیقه‌ای
                    let timer = 120; // 2 دقیقه به ثانیه
                    $button.prop('disabled', true); // غیرفعال کردن دکمه
                    const interval = setInterval(function() {
                        const minutes = Math.floor(timer / 60);
                        const seconds = timer % 60;
                        $button.text(`${minutes}:${seconds < 10 ? '0' + seconds : seconds}`); // نمایش تایمر
                        timer--;
    
                        if (timer < 0) {
                            clearInterval(interval); // پاک کردن تایمر
                            $button.prop('disabled', false); // فعال کردن دوباره دکمه
                            $button.text('ارسال مجدد'); // بازگرداندن متن اصلی
                        }
                    }, 1000); // هر ثانیه یک بار اجرا شود
                } else {
                    alert(response.message || 'خطایی رخ داده است.');
                }
            },
            error: function(xhr, status, error) {
                let errorMessage = 'خطا در ارتباط با سرور: ';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage += xhr.responseJSON.message;
                } else {
                    errorMessage += error;
                }
                alert(errorMessage);
            },
        });
    });
      
    
    $(document).on('click', '#resend_otp_second_code', function() {
        const national_id = $('#national_id').attr('data-nationalid');
        const tracking_code = $('input#tracking_code').val();
        const $button = $(this); // ذخیره مرجع دکمه برای تغییر متن
        
        $.ajax({
            url: ajax_object.ajaxurl, // استفاده از ajax_object که در wp_localize_script تعریف شده
            method: 'POST',
            dataType: 'json', // انتظار دریافت پاسخ JSON
            data: {
                action: 'resend_otp_second_code',
                national_id: national_id,
                tracking_code: tracking_code,
            },
            success: function(response) {
                if (response.success) {
                    // ایجاد تایمر 2 دقیقه‌ای
                    let timer = 120; // 2 دقیقه به ثانیه
                    $button.prop('disabled', true); // غیرفعال کردن دکمه
                    const interval = setInterval(function() {
                        const minutes = Math.floor(timer / 60);
                        const seconds = timer % 60;
                        $button.text(`${minutes}:${seconds < 10 ? '0' + seconds : seconds}`); // نمایش تایمر
                        timer--;

                        if (timer < 0) {
                            clearInterval(interval); // پاک کردن تایمر
                            $button.prop('disabled', false); // فعال کردن دوباره دکمه
                            $button.text('ارسال مجدد'); // بازگرداندن متن اصلی
                            
                        }
                    }, 1000); // هر ثانیه یک بار اجرا شود
                } else {
                    alert(response.message || 'خطایی رخ داده است.');
                }
            },
            error: function(xhr, status, error) {
                let errorMessage = 'خطا در ارتباط با سرور: ';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage += xhr.responseJSON.message;
                } else {
                    errorMessage += error;
                }
                alert(errorMessage);
            },
        });
    });    
    
    $(document).on('click', '#submit_form_gateway', function() {
        const national_id = $('#national_id').attr('data-nationalid');
        const amount_pay = parseInt($('input#amount_pay').val().replace(/,/g, ''), 10);
        const order_id = $('#custom-payment-page').data('order');
        const tracking_code = $('input#tracking_code').val();
        const otp_sended_code = $('input#second_code').val();
        const $button = $(this); // ذخیره مرجع دکمه برای تغییر متن
        if (!amount_pay || amount_pay == 0) {
            alert('مبلغ پرداختی با اعتبار کیف پول');
            return;
        }

        $.ajax({
            url: ajax_object.ajaxurl, // استفاده از ajax_object که در wp_localize_script تعریف شده
            method: 'POST',
            dataType: 'json', // انتظار دریافت پاسخ JSON
            data: {
                action: 'submit_form_gateway',
                national_id: national_id,
                amount_pay: amount_pay,
                order_id: order_id,
                tracking_code: tracking_code,
                otp_sended_code: otp_sended_code,
            },
            success: function(response) {
                if (response.success) {
                    // داده‌های تراکنش از پاسخ ایجکس
                    const callback = response.data.callback;
                    window.location.href = callback;
                } else {
                    alert(response.message || 'خطایی رخ داده است.');
                }
            },            
            error: function(xhr, status, error) {
                let errorMessage = 'خطا در ارتباط با سرور: ';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage += xhr.responseJSON.message;
                } else {
                    errorMessage += error;
                }
                alert(errorMessage);
            },
        });
    });
});
