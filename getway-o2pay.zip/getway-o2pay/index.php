
<?php
/*
Plugin Name: درگاه پرداخت o2pay
Description: درگاه پرداخت o2pay
Version: 1.0
Author: Vahid Mahyari
*/

// جلوگیری از دسترسی مستقیم
if (!defined('ABSPATH')) {
    exit;
}

// شامل کردن فایل‌های مورد نیاز
include_once 'includes/gateway.php';
include_once 'includes/gateway_difference.php';
include_once 'includes/AjaxHandler.php';

// ثبت مسیر transaction-details
add_action('init', 'register_transaction_details_page');
function register_transaction_details_page() {
    add_rewrite_rule('^transactiondetails/?$', 'index.php?transaction_details=1', 'top');
}

add_filter('query_vars', 'register_transaction_details_query_var');
function register_transaction_details_query_var($vars) {
    $vars[] = 'transaction_details';
    return $vars;
}

add_action('template_include', 'load_transaction_details_template');
function load_transaction_details_template($template) {
    if (get_query_var('transaction_details') === '1') {
        return plugin_dir_path(__FILE__) . 'includes/transaction-details.php';
    }
    return $template;
}

// ثبت مسیر o2pay-gateway
add_action('init', 'register_custom_gateway_page');
function register_custom_gateway_page() {
    add_rewrite_rule('^o2paygateway/?$', 'index.php?o2pay_gateway=1', 'top');
}

add_filter('query_vars', 'register_o2pay_gateway_query_var');
function register_o2pay_gateway_query_var($vars) {
    $vars[] = 'o2pay_gateway';
    return $vars;
}

add_action('template_include', 'load_o2pay_gateway_template');
function load_o2pay_gateway_template($template) {
    if (get_query_var('o2pay_gateway') === '1') {
        return plugin_dir_path(__FILE__) . 'includes/o2pay-gateway.php';
    }
    return $template;
}

// بازنشانی قوانین بازنویسی هنگام فعال‌سازی
register_activation_hook(__FILE__, 'custom_flush_rewrite_rules');
function custom_flush_rewrite_rules() {
    register_transaction_details_page();
    register_custom_gateway_page();
    flush_rewrite_rules();
}

// حذف قوانین بازنویسی هنگام غیرفعال‌سازی
register_deactivation_hook(__FILE__, 'custom_flush_rewrite_rules_on_deactivation');
function custom_flush_rewrite_rules_on_deactivation() {
    flush_rewrite_rules();
}

// حذف اطلاعات سشن پس از پرداخت
add_action('woocommerce_thankyou', 'clear_order_session_after_payment');
function clear_order_session_after_payment($order_id) {
    if (WC()->session) {
        WC()->session->__unset('order_awaiting_payment');
        WC()->session->__unset('custom_payment_session');
    }
}

// محدود کردن دسترسی به صفحه پرداخت
add_action('template_redirect', 'restrict_payment_page_access');
function restrict_payment_page_access() {
    if (is_checkout() && !is_order_received_page()) {
        $order_id = WC()->session->get('order_awaiting_payment');
        if ($order_id) {
            $order = wc_get_order($order_id);

            if ($order && $order->get_status() !== 'pending') {
                wp_die(__('این سفارش قبلاً پرداخت شده است یا منقضی شده است.', 'woocommerce'), __('دسترسی غیرمجاز', 'woocommerce'));
            }
        }
    }
}

// اضافه کردن استایل و اسکریپت‌ها
function add_stylesheet_to_head() {
    wp_register_style('gateway', plugins_url('assets/css/gateway.css', __FILE__));
    wp_enqueue_style('gateway');

    wp_enqueue_script('ajax', plugin_dir_url(__FILE__) . 'assets/js/ajax.js', ['jquery'], '1.0', true);
    wp_enqueue_script('gateway', plugin_dir_url(__FILE__) . 'assets/js/gateway.js', ['jquery'], '1.0', true);

    wp_localize_script('ajax', 'ajax_object', [
        'ajaxurl' => admin_url('admin-ajax.php'),
    ]);
}
add_action('wp_enqueue_scripts', 'add_stylesheet_to_head');

// نمایش اطلاعات پاسخ درگاه در پنل ادمین
add_action('woocommerce_admin_order_data_after_order_details', 'display_gateway_response_in_admin', 10, 1);
function display_gateway_response_in_admin($order) {
    $gateway_response = get_post_meta($order->get_id(), '_gateway_response', true);
    $national_id = get_post_meta($order->get_id(), '_national_id', true);
    $wallet_price = get_post_meta($order->get_id(), '_wallet_payment_price', true);

    if (!empty($gateway_response)) {
        $response_data = maybe_unserialize($gateway_response);

        switch ($response_data['data']['data']['category']) {
            case 'appliance':
                $cat = 'فروشگاه لوازم خانگی';
                break;
            case 'motor':
                $cat = 'فروشگاه موتور سیکلت';
                break;
            case 'cars':
                $cat = 'فروشگاه خودرو';
                break;
            case 'digital':
                $cat = 'فروشگاه لوازم دیجیتال';
                break;
            default:
                $cat = 'دسته بندی نشده';
                break;
        }

        echo '<div class="form-field form-field-wide">';
        echo '<h3>' . __('اطلاعات کیف پول', 'woocommerce') . '</h3>';
        if (isset($response_data['data']['data'])) {
            echo '<p><strong>' . __('نام:', 'woocommerce') . '</strong> ' . esc_html($response_data['data']['data']['firstname']) . '</p>';
            echo '<p><strong>' . __('نام خانوادگی:', 'woocommerce') . '</strong> ' . esc_html($response_data['data']['data']['lastname']) . '</p>';
            echo '<p><strong>' . __('شماره تلفن:', 'woocommerce') . '</strong> ' . esc_html($response_data['data']['data']['phone_number']) . '</p>';
            echo '<p><strong>' . __('کدملی:', 'woocommerce') . '</strong> ' . esc_html($national_id) . '</p>';
            echo '<p><strong>' . __('دسته‌بندی:', 'woocommerce') . '</strong> ' . esc_html($cat) . '</p>';
            echo '<p><strong>' . __('میزان استفاده از کیف پول:', 'woocommerce') . '</strong> ' . esc_html($wallet_price) . '</p>';
        }
        echo '</div>';
    } else {
        echo '<div class="form-field form-field-wide">';
        echo '<h3>' . __('اطلاعات درگاه پرداخت', 'woocommerce') . '</h3>';
        echo '<p>' . __('هیچ اطلاعاتی برای این سفارش ذخیره نشده است.', 'woocommerce') . '</p>';
        echo '</div>';
    }
}


// افزودن وضعیت سفارشی "در انتظار پرداخت مابه‌التفاوت"
add_action('init', function () {
    register_post_status('wc-difference', [
        'label'                     => 'در انتظار پرداخت مابه‌التفاوت',
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop('در انتظار پرداخت مابه‌التفاوت (%s)', 'در انتظار پرداخت مابه‌التفاوت (%s)'),
    ]);
});

// افزودن وضعیت جدید به لیست وضعیت‌های سفارش ووکامرس
add_filter('wc_order_statuses', function ($order_statuses) {
    $new_statuses = [];
    foreach ($order_statuses as $key => $status) {
        $new_statuses[$key] = $status;
        if ('wc-pending' === $key) {
            $new_statuses['wc-difference'] = 'در انتظار پرداخت مابه‌التفاوت';
        }
    }
    return $new_statuses;
});

// اطمینان از معتبر بودن وضعیت سفارشی برای ذخیره در سفارش‌ها
add_filter('woocommerce_valid_order_statuses', function ($statuses) {
    $statuses[] = 'wc-difference';
    return $statuses;
});

// هندل کردن تغییر وضعیت سفارش به وضعیت سفارشی
add_action('woocommerce_order_status_changed', function ($order_id, $old_status, $new_status) {
    if ('wc-difference' === $new_status) {
        $order = wc_get_order($order_id);
        if ($order) {
            $order->add_order_note('وضعیت سفارش به "در انتظار پرداخت مابه‌التفاوت" تغییر یافت.');
        }
    }
}, 10, 3);

// افزودن وضعیت به عملیات دسته‌ای (Bulk Actions) در مدیریت سفارش‌ها
add_filter('bulk_actions-edit-shop_order', function ($actions) {
    $actions['mark_wc-awaiting-difference-payment'] = 'تغییر وضعیت به: در انتظار پرداخت مابه‌التفاوت';
    return $actions;
});

// پردازش عملیات دسته‌ای برای تغییر وضعیت
add_action('handle_bulk_actions-edit-shop_order', function ($redirect_to, $action, $post_ids) {
    if ('mark_wc-awaiting-difference-payment' === $action) {
        foreach ($post_ids as $post_id) {
            $order = wc_get_order($post_id);
            if ($order) {
                $order->update_status('wc-difference', 'وضعیت سفارش در عملیات دسته‌ای تغییر یافت.');
            }
        }
        $redirect_to = add_query_arg('bulk_status_updated', count($post_ids), $redirect_to);
    }
    return $redirect_to;
}, 10, 3);

// نمایش پیام موفقیت در تغییر وضعیت‌های دسته‌ای
add_action('admin_notices', function () {
    if (!empty($_REQUEST['bulk_status_updated'])) {
        $count = intval($_REQUEST['bulk_status_updated']);
        printf('<div id="message" class="updated notice is-dismissible"><p>%d سفارش با موفقیت به وضعیت "در انتظار پرداخت مابه‌التفاوت" تغییر یافت.</p></div>', $count);
    }
});


// نمایش میزان تخفیف در بخش جمع کل سفارش‌ها (بعد از هزینه حمل و نقل)
add_action('woocommerce_admin_order_totals_after_shipping', function ($order_id) {
    $discount_amount = get_post_meta($order_id, '_wallet_payment_price', true); // گرفتن مقدار تخفیف از متادیتای سفارش
    if ($discount_amount) {
        ?>
        <tr>
            <td class="label">میزان کیف پول:</td>
            <td width="1%"></td>
            <td class="total">
                <?php echo wc_price($discount_amount); // نمایش مقدار تخفیف به صورت قیمت ?>
            </td>
        </tr>
        <?php
    }
});

add_action('woocommerce_admin_order_totals_after_shipping', function ($order_id) {
    $gateway_zibal = get_post_meta($order_id, '_gateway_zibal_price', true); // گرفتن مقدار تخفیف از متادیتای سفارش
    if ($gateway_zibal) {
        ?>
        <tr>
            <td class="label">میزان پرداخت شده:</td>
            <td width="1%"></td>
            <td class="total">
                <?php echo wc_price($gateway_zibal); // نمایش مقدار تخفیف به صورت قیمت ?>
            </td>
        </tr>
        <?php
    }
});

add_filter('woocommerce_get_order_item_totals', function ($total_rows, $order, $tax_display) {
    // گرفتن مقادیر سفارشی از متادیتای سفارش
    $wallet_payment = get_post_meta($order->get_id(), '_wallet_payment_price', true);
    $gateway_payment = get_post_meta($order->get_id(), '_gateway_zibal_price', true);

    // افزودن اطلاعات سفارشی به آرایه جداگانه
    $custom_rows = [];

    if (!empty($wallet_payment)) {
        $custom_rows['wallet_payment'] = [
            'label' => 'میزان پرداخت از کیف پول:',
            'value' => wc_price($wallet_payment),
        ];
    }

    if (!empty($gateway_payment)) {
        $custom_rows['gateway_payment'] = [
            'label' => 'میزان پرداخت آنلاین:',
            'value' => wc_price($gateway_payment),
        ];
    }

    // بازآرایی: اطلاعات سفارشی قبل از قیمت نهایی
    if (isset($total_rows['order_total'])) {
        $order_total = $total_rows['order_total']; // ذخیره قیمت نهایی
        unset($total_rows['order_total']); // حذف قیمت نهایی موقتاً

        // ادغام اطلاعات سفارشی قبل از قیمت نهایی
        $total_rows = array_merge($total_rows, $custom_rows, ['order_total' => $order_total]);
    } else {
        // اگر قیمت نهایی نبود (استثنایی)، فقط اطلاعات سفارشی اضافه شود
        $total_rows = array_merge($total_rows, $custom_rows);
    }

    return $total_rows;
}, 10, 3);
