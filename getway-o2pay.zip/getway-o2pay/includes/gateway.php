<?php

if (!defined('ABSPATH')) {
    exit; // جلوگیری از دسترسی مستقیم
}
add_action('init', function () {
    if (class_exists('WC_Session_Handler') && !WC()->session) {
        WC()->session = new WC_Session_Handler();
        WC()->session->init();
    }
});

// افزودن درگاه به لیست درگاه‌های ووکامرس
add_filter('woocommerce_payment_gateways', 'add_custom_gateway');
function add_custom_gateway($gateways) {
    error_log('Custom Gateway Added'); // برای تست
    $gateways[] = 'WC_Gateway_Custom';
    return $gateways;
}


// تعریف کلاس درگاه
add_action('plugins_loaded', 'init_custom_gateway');
function init_custom_gateway() {
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    class WC_Gateway_Custom extends WC_Payment_Gateway {
        public function __construct() {
            $this->id = 'o2pay_gateway';
            $this->icon = ''; // آدرس تصویر لوگوی درگاه
            $this->method_title = __('درگاه بانکی اختصاصی', 'woocommerce');
            $this->method_description = __('پرداخت با کیف پول و مابه‌التفاوت.', 'woocommerce');
            $this->has_fields = true; // در اینجا فرم فیلدها در صفحه پرداخت نمایش داده نمی‌شود.

            // تنظیمات درگاه
            $this->init_form_fields();
            $this->init_settings();

            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');

            // ذخیره تنظیمات
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
        }

        // تنظیمات درگاه در پیشخوان
        public function init_form_fields() {
            $this->form_fields = [
                'enabled' => [
                    'title' => 'فعال‌سازی',
                    'type' => 'checkbox',
                    'label' => 'فعال‌سازی این درگاه',
                    'default' => 'yes',
                ],
                'title' => [
                    'title' => 'عنوان درگاه',
                    'type' => 'text',
                    'description' => 'عنوانی که در صفحه پرداخت نمایش داده می‌شود.',
                    'default' => 'درگاه اعتباری o2pay',
                ],
                'description' => [
                    'title' => 'توضیحات',
                    'type' => 'textarea',
                    'description' => 'توضیحاتی که در صفحه پرداخت نمایش داده می‌شود.',
                    'default' => 'پرداخت اعتباری از o2pay',
                ],
                'api_key' => [
                    'title' => 'API KEY',
                    'type' => 'text',
                    'description' => 'ارائه شده توسط o2pay',
                ],                
                'api_secret' => [
                    'title' => 'API SECRET',
                    'type' => 'text',
                    'description' => 'ارائه شده توسط o2pay.',
                ],
            ];
        }

        public function payment_fields() {
            if ($this->description) {
                echo wpautop(wp_kses_post($this->description));
            }
            $order_id = null;

            // اگر سفارش قبلاً ایجاد نشده باشد
            if (!WC()->session->get('order_awaiting_payment')) {
                $checkout = new WC_Checkout();

                // آرایه‌ای شامل جزئیات سفارش
                $order_data = [
                    'payment_method' => 'o2pay_gateway', // شناسه روش پرداخت شما
                    'billing_email' => WC()->customer->get_billing_email(),
                    'billing_first_name' => WC()->customer->get_billing_first_name(),
                    'billing_last_name' => WC()->customer->get_billing_last_name(),
                ];

                // ایجاد سفارش
                $order_id = $checkout->create_order($order_data);

                // ذخیره `order_id` در سشن
                WC()->session->set('order_awaiting_payment', $order_id);
            } else {
                $order_id = WC()->session->get('order_awaiting_payment');
            }

            if (!$order_id) {
                wc_add_notice(__('خطا در ایجاد سفارش. لطفاً دوباره تلاش کنید.', 'woocommerce'), 'error');
                return;
            }

            // نمایش فرم
            echo '<div id="custom_gateway_national_id_field">';
                echo '<p class="form-row form-row-wide">';
                    echo '<label for="national_id">' . __('کد ملی:', 'woocommerce') . ' <span class="required">*</span></label>';
                    echo '<input type="text" class="input-text" name="national_id" id="national_id" placeholder="' . __('کد ملی خود را وارد کنید', 'woocommerce') . '" required>';
                echo '</p>';
                echo '<input type="hidden" name="order_id" value="' . esc_attr($order_id) . '">';
            echo '</div>';
        }

        
        public function validate_fields() {
            $national_id = isset($_POST['national_id']) ? sanitize_text_field($_POST['national_id']) : '';
            $order_id = isset($_POST['order_id']) ? sanitize_text_field($_POST['order_id']) : '';
        
            // اعتبارسنجی کد ملی
            if (empty($national_id)) {
                wc_add_notice(__('لطفاً کد ملی خود را وارد کنید.', 'woocommerce'), 'error');
                return;
            } elseif (!preg_match('/^\d{10}$/', $national_id)) {
                wc_add_notice(__('کد ملی وارد شده معتبر نیست.', 'woocommerce'), 'error');
                return;
            }
        
            // اعتبارسنجی شناسه سفارش
            if (empty($order_id)) {
                wc_add_notice(__('شناسه سفارش موجود نیست.', 'woocommerce'), 'error');
                return;
            }
        
            $order = wc_get_order($order_id);
        
            if (!$order) {
                wc_add_notice(__('سفارش معتبر نیست.', 'woocommerce'), 'error');
                return;
            }
        
            // اطلاعات درگاه
            $o2pay_gateway = get_option('woocommerce_o2pay_gateway_settings');
            $api_key = $o2pay_gateway['api_key'];
            $api_secret = $o2pay_gateway['api_secret'];
            $order_total = $order->get_total();
        
            if (empty($api_key) || empty($api_secret)) {
                wc_add_notice(__('پیکربندی درگاه پرداخت انجام نشده است.', 'woocommerce'), 'error');
                return;
            }
        
            // تولید توکن
            $date = strtotime(current_time('mysql'));
            $algo = 'sha256';
            $key_data = $order_id . $api_key . $order_total . $national_id . $date;
            $token = hash_hmac($algo, $key_data, $api_secret);
        
            // ذخیره اطلاعات در متای سفارش
            update_post_meta($order_id, '_national_id', $national_id);
            update_post_meta($order_id, '_gateway_token', $token);
        
            // داده‌های ارسال به API
            $data = [
                'merchant_id' => $api_key,
                'token' => $token,
                'order_id' => $order_id,
                'credit_amount' => $order_total,
                'national_id' => $national_id,
                'date' => $date,
            ];
        
            // مقداردهی cURL
            $ch = curl_init();
        
            // تنظیمات cURL
            curl_setopt($ch, CURLOPT_URL, 'https://test.o2pay.app/wp-json/webservice/v1/get-wallet/');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // برای دریافت پاسخ
            curl_setopt($ch, CURLOPT_POST, true); // ارسال درخواست POST
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data)); // داده‌های ارسال به صورت JSON
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
            ]); // هدرهای مورد نیاز
        
            // ارسال درخواست و دریافت پاسخ
            $response = curl_exec($ch);
            error_log('Raw Response: ' . print_r($response, true));
            // بررسی خطاها
            if (curl_errno($ch)) {
                $error_msg = curl_error($ch);
                curl_close($ch);
                error_log('cURL Error: ' . $error_msg);
                wc_add_notice(__('خطا در ارتباط با سرور: ' . $error_msg, 'woocommerce'), 'error');
                return;
            }
        
            // بستن اتصال cURL
            curl_close($ch);
        
            // تبدیل پاسخ JSON به آرایه PHP
            if (is_string($response) && is_array(json_decode($response, true)) && (json_last_error() === JSON_ERROR_NONE)) {
                $body = json_decode($response, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    error_log('JSON Decode Error: ' . json_last_error_msg());
                    wc_add_notice(__('خطا در پردازش پاسخ سرور: ' . json_last_error_msg(), 'woocommerce'), 'error');
                    return;
                }
            } else {
                error_log('Invalid JSON Response: ' . $response);
                wc_add_notice(__('پاسخ سرور معتبر نیست.', 'woocommerce'), 'error');
                return;
            }
        
            // بررسی موفقیت‌آمیز بودن پاسخ
            if ( $body['success'] === true) {
                update_post_meta($order_id, '_gateway_response', $body); // ذخیره پاسخ
            } else {
                $error_message = $body['data']['message'] ?? 'خطای نامشخص';
                wc_add_notice(__('خطا: ' . $error_message, 'woocommerce'), 'error');
                return;
            }
        }
        
        
        public function process_payment($order_id) {
            $order = wc_get_order($order_id);
        
            // خواندن اطلاعات از متای سفارش
            $national_id = get_post_meta($order_id, '_national_id', true);
            $token = get_post_meta($order_id, '_gateway_token', true);
        
            // بررسی وجود اطلاعات لازم
            if (empty($national_id) || empty($token)) {
                wc_add_notice(__('اطلاعات پرداخت کامل نیست.', 'woocommerce'), 'error');
                return;
            }
        
            // تولید شناسه یونیک و زمان انقضا
            $unique_token = $order->get_order_key();
            $expiration_time = time() + (10 * 60); // 10 دقیقه اعتبار
        
            // ذخیره اطلاعات در متای سفارش
            update_post_meta($order_id, '_custom_payment_token', $unique_token);
            update_post_meta($order_id, '_custom_payment_expiration', $expiration_time);
            

            $order->update_status('pending', __('در انتظار پرداخت', 'woocommerce'));

            // ذخیره اطلاعات در سشن کاربر
            WC()->session->set('custom_payment_session', [
                'order_id' => $order_id,
                'token' => $unique_token,
                'expiration' => $expiration_time,
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
            ]);
        
            // انتقال اطلاعات به صفحه پرداخت سفارشی
            $redirect_url = add_query_arg([
                'token' => $unique_token,
                'national_id' => $national_id,
                'gateway_token' => $token,
            ], site_url('/o2paygateway'));
        
            // بازگرداندن نتیجه موفقیت و ریدایرکت
            return [
                'result' => 'success',
                'redirect' => $redirect_url,
            ];
        }
        
        
        
    }
    
}

function validate_payment_token() {
    // بررسی اینکه آیا کاربر به صفحه درگاه سفارشی دسترسی دارد
    if (is_page() && isset($_GET['token']) && strpos($_SERVER['REQUEST_URI'], '/o2paygateway') !== false) {
        $token = sanitize_text_field($_GET['token']);
        $session_data = WC()->session->get('custom_payment_session');

        if (!$session_data || $session_data['token'] !== $token) {
            wp_die(__('دسترسی غیرمجاز یا لینک منقضی شده است.', 'woocommerce'));
        }

        $expiration_time = get_post_meta($session_data['order_id'], '_custom_payment_expiration', true);

        if (time() > $expiration_time) {
            wp_die(__('لینک پرداخت منقضی شده است.', 'woocommerce'));
        }

        // در صورت معتبر بودن توکن، ادامه پردازش صفحه درگاه
    }
}
add_action('template_redirect', 'validate_payment_token');
