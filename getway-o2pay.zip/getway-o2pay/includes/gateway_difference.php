<?php

if (!defined('ABSPATH')) {
    exit; // جلوگیری از دسترسی مستقیم
}

class Gateway_Difference_Handler {

    /**
     * پردازش مابه‌تفاوت و هدایت به درگاه پرداخت
     *
     * @param int $order_id
     * @param float $credit_amount
     * @return array
     */
    public static function handle_difference($order_id, $credit_amount) {
        $order = wc_get_order($order_id);
    
        if (!$order) {
            return [
                'success' => false,
                'message' => 'سفارش معتبر نیست.',
            ];
        }
    
        $order_total = $order->get_total() * 10; // تبدیل به ریال
        $difference = $order_total - $credit_amount;
    
        // استفاده از صفحه thankyou ووکامرس به عنوان callback
        $callback_url = $order->get_checkout_order_received_url();
    
        // بررسی مابه‌التفاوت
        if ($difference > 0) {
            // قرار دادن سفارش در وضعیت "در انتظار پرداخت مابه‌التفاوت"
            $order->update_status('wc-difference', __('سفارش در وضعیت انتظار پرداخت مابه‌التفاوت قرار گرفت.', 'woocommerce'));
            update_post_meta($order_id, '_gateway_zibal_price', $difference);
            $parameters = [
                "merchant"   => 'zibal', // جایگزین با کلید مرچنت زیبال
                "callbackUrl"=> $callback_url,
                "amount"     => $difference,
                "orderId"    => $order_id,
                "mobile"     => $order->get_billing_phone(),
            ];
    
            $response = self::postToZibal('request', $parameters);
    
            if (isset($response->result) && $response->result == 100) {
                $startGateWayUrl = "https://gateway.zibal.ir/start/" . $response->trackId;
    
                return [
                    'success' => true,
                    'callback' => $startGateWayUrl,
                ];
            } else {
                // اضافه کردن یادداشت خطا در سفارش
                $order->add_order_note('خطا در پرداخت مابه‌التفاوت: ' . self::resultCodes($response->result ?? 0));
                return [
                    'success' => false,
                    'message' => self::resultCodes($response->result ?? 0),
                ];
            }
        }
    
        return [
            'success' => true,
            'callback' => $callback_url,
        ];
    }
    

    /**
     * پردازش بازگشت از درگاه پرداخت
     */
    public static function handle_callback() {
        $trackId = sanitize_text_field($_GET['trackId'] ?? '');
        $orderId = sanitize_text_field($_GET['orderId'] ?? '');

        if (empty($trackId) || empty($orderId)) {
            wp_die(__('اطلاعات پرداخت ناقص است.', 'woocommerce'));
        }

        $parameters = [
            "merchant" => ZIBAL_MERCHANT_KEY,
            "trackId" => $trackId,
        ];

        $response = self::postToZibal('verify', $parameters);

        if ($response && $response->result == 100) {
            $order = wc_get_order($orderId);
            if ($order && $order->get_status() !== 'completed') {
                $order->payment_complete();
                $order->add_order_note(sprintf(
                    __('پرداخت با موفقیت انجام شد. Track ID: %s', 'woocommerce'),
                    $trackId
                ));
            }
            wp_redirect($order->get_checkout_order_received_url());
            exit;
        } else {
            wp_die(sprintf(
                __('پرداخت ناموفق: %s', 'woocommerce'),
                self::resultCodes($response->result ?? 0)
            ));
        }
    }

    /**
     * اتصال به API زیبال
     *
     * @param string $path
     * @param array $parameters
     * @return stdClass
     */
    public static function postToZibal($path, $parameters) {
        $url = 'https://gateway.zibal.ir/v1/' . $path;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($parameters));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            error_log('cURL Error: ' . curl_error($ch));
        }

        curl_close($ch);
        return json_decode($response);
    }

    /**
     * پیام‌های مربوط به کدهای نتیجه‌گیری
     *
     * @param int $code
     * @return string
     */
    public static function resultCodes($code) {
        $messages = [
            100 => 'با موفقیت تایید شد',
            102 => 'merchant یافت نشد',
            103 => 'merchant غیرفعال',
            104 => 'merchant نامعتبر',
            105 => 'amount بایستی بزرگتر از 1,000 ریال باشد',
            106 => 'callbackUrl نامعتبر می‌باشد.',
            113 => 'amount مبلغ تراکنش از سقف میزان تراکنش بیشتر است.',
            201 => 'قبلا تایید شده',
            202 => 'سفارش پرداخت نشده یا ناموفق بوده است',
            203 => 'trackId نامعتبر می‌باشد',
        ];

        return $messages[$code] ?? 'وضعیت مشخص شده معتبر نیست';
    }

    /**
     * پیام‌های وضعیت پرداخت
     *
     * @param int $code
     * @return string
     */
    public static function statusCodes($code) {
        $statuses = [
            -1 => 'در انتظار پرداخت',
            -2 => 'خطای داخلی',
            1 => 'پرداخت شده - تاییدشده',
            2 => 'پرداخت شده - تاییدنشده',
            3 => 'لغوشده توسط کاربر',
            4 => 'شماره کارت نامعتبر می‌باشد',
            5 => 'موجودی حساب کافی نمی‌باشد',
            6 => 'رمز واردشده اشتباه می‌باشد',
            7 => 'تعداد درخواست‌ها بیش از حد مجاز می‌باشد',
            8 => 'تعداد پرداخت اینترنتی روزانه بیش از حد مجاز می‌باشد',
            9 => 'مبلغ پرداخت اینترنتی روزانه بیش از حد مجاز می‌باشد',
            10 => 'صادرکننده‌ی کارت نامعتبر می‌باشد',
            11 => 'خطای سوییچ',
            12 => 'کارت قابل دسترسی نمی‌باشد',
        ];

        return $statuses[$code] ?? 'وضعیت مشخص شده معتبر نیست';
    }
}
