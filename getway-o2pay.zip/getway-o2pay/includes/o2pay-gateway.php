<?php
if (!defined('ABSPATH')) {
    exit; // جلوگیری از دسترسی مستقیم
}

// بررسی توکن و سفارش
if (!isset($_GET['token'])) {
    wp_die(__('دسترسی غیرمجاز: توکن یافت نشد.', 'woocommerce'));
}

$token = sanitize_text_field($_GET['token']);
$session_data = WC()->session->get('custom_payment_session');

if (!$session_data || $session_data['token'] !== $token) {
    wp_die(__('دسترسی غیرمجاز: لینک نامعتبر یا منقضی شده است.', 'woocommerce'));
}


$order_id = $session_data['order_id'];
$order = wc_get_order($order_id);

// دریافت متای سفارش
$gateway_response = get_post_meta($order_id, '_gateway_response', true);
$national_id = get_post_meta($order_id, '_national_id', true);

// var_dump($gateway_response);

// بررسی موفقیت پاسخ
if (isset($gateway_response['success']) && $gateway_response['success'] === true) {
    // دسترسی به داده‌های داخل 'data'
    $response_data = $gateway_response['data'];

    // پیام موفقیت
    $message = isset($response_data['message']) ? $response_data['message'] : '';

    // اطلاعات جزئیات
    if (isset($response_data['data'])) {
        $details = $response_data['data'];
        
        $firstname = isset($details['firstname']) ? $details['firstname'] : '';
        $lastname = isset($details['lastname']) ? $details['lastname'] : '';

        // شماره تلفن
        $phone_number = isset($details['phone_number']) ? $details['phone_number'] : '';

        // دسته‌بندی
        $category = isset($details['category']) ? $details['category'] : '';

        // مبلغ باقی‌مانده
        $amount_remains = isset($details['amount_remains']) ? $details['amount_remains'] : '';

        $merchant_cat = isset($details['merchant_cat']) ? $details['merchant_cat'] : '';
        $merchant_name = isset($details['merchant_name']) ? $details['merchant_name'] : '';
        $merchant_national_id = isset($details['merchant_national_id']) ? $details['merchant_national_id'] : '';
        $tracking_code = isset($details['tracking_code']) ? $details['tracking_code'] : '';

        switch ($merchant_cat) {
            case 'appliance':
                $cat = 'فروشگاه لوازم خانگی';
                break;
            case 'motor':
                $cat = 'فروشگاه موتور سیکلت';
                break;
            case 'cars':
                $cat = 'فروشگاه خودرو';
                break;
            case 'digital':
                $cat = 'فروشگاه لوازم دیجیتال';
                break;
            default:
                $cat = 'دسته بندی نشده';
                break;
        }
    }
} else {
    wp_die(__('خطا در انتقال به درگاه اعتباری o2pay', 'woocommerce'));
}


if (!$order) {
    wp_die(__('سفارش معتبر نیست.', 'woocommerce'));
}

error_log('Session Data: ' . print_r(WC()->session->get('custom_payment_session'), true));

// بررسی انقضای لینک
$expiration_time = get_post_meta($order_id, '_custom_payment_expiration', true);

if (time() > $expiration_time) {
    wp_die(__('لینک پرداخت منقضی شده است.', 'woocommerce'));
}

// چک کردن مرورگر فعلی
$stored_user_agent = $session_data['user_agent'];
$stored_expiration = $session_data['expiration'];
$current_user_agent = $_SERVER['HTTP_USER_AGENT'];
$price_total = $order->get_total();
if($price_total >= $amount_remains){
    $price = $amount_remains;
    $price_remained = $amount_remains - $price_total;
}elseif($price_total <= $amount_remains){
    $price = $price_total;
    $price_remained = 0;
}else{
    $price = 0;
    $price_remained = 0;
}
if ($stored_user_agent !== $current_user_agent) {
    wp_die(__('این لینک فقط در مرورگر اصلی قابل استفاده است.', 'woocommerce'));
}

$url = plugin_dir_url( __DIR__ );;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="robots" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo __('درگاه پرداخت اقساطی o2pay', 'woocommerce'); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <div id="custom-payment-page" class="container container-custom" data-order="<?= $order_id ?>">
        <div class="row">
            <div class="col-12 col-md-6">
                <img src="<?= $url ?>/assets/img/top-right.png" class="w-100 img">
                <div class="form-content">
                    <div class="top-form-content">
                        <div class="fullname"><?= $firstname .' '. $lastname ?></div>
                        <div class="national_id" id="national_id" data-nationalid="<?= $national_id ?>"><?= $national_id ?></div>
                    </div>

                    <div id="national-id-form">
                        <div class="time-expiration">
                            <span class="title-expiration"><img src="<?= $url ?>/assets/img/Time.png">زمان باقی‌مانده:</span>
                            <span id="time-expiration" data-time="<?= $stored_expiration ?>"><span class="min"></span>:<span class="sec"></span></span>
                        </div>
                        <div class="amount-remains">
                            <span class="title-amount-remains">
                                <img class="img" src="<?= $url ?>/assets/img/Wallet.png">
                                <span>اعتبار کیف پول شما</span>
                            </span>
                            <span class="value-amount-remains">
                                <span><?= number_format($amount_remains) ?></span>
                                <span>تومان</span>
                            </span>
                        </div>                        
                        <div class="order-total">
                            <span class="title-amount-remains">
                                <img class="img" src="<?= $url ?>/assets/img/coins-hand.png">
                                <span>مبلغ قابل پرداخت</span>
                            </span>
                            <span class="value-amount-remains">
                                <span><?= number_format($price_total); ?></span>
                                <span>تومان</span>
                            </span>
                        </div>
                        <form class="amount-pay">
                            <div class="col-input">
                                <label for="amount-pay">مبلغ پرداختی با اعتبار کیف پول</label>
                                <input type="text" name="amount-pay" id="amount_pay" value="<?= $price ?>" max="<?= $price ?>">
                                <span class="price-symbol">تومان</span>
                            </div>
                            <div class="col-checkbox">
                                <input type="checkbox" name="total-pay">
                                <label for="total-pay">پرداخت با کل اعتبار کیف پول</label>
                            </div>
                            <div class="amount-remained">
                                <span class="title-amount-remained">باقی مانده‌ی نقدی (مابه‌التفاوت)</span>
                                <div class="value-amount-remained">
                                    <span class="value-pay-remained"><?= number_format(abs($price_remained)) ?></span>
                                    <span class="price-symbol">تومان</span>
                                </div>
                            </div>
                            <p class="desc-amount-remained">توضیحات پرداخت مبلغ ما به‌التفاوت</p>
                            <div class="otp-second-code">
                                <div class="col-input w-100">
                                    <input type="text" name="second-code" id="second_code" value="" placeholder="کد ارسال شده را وارد نمائید" require>
                                </div>
                                <span class="btn" id="send_otp_second_code">ارسال رمز دوم</span>
                            </div>
                            <div class="capcha-form mt-3">

                            </div>
                            <div class="submit-form-gateway">
                                <span class="btn btn-submit" id="submit_form_gateway">پرداخت</span>
                                <span class="btn btn-cancell" id="cancell_form_gateway">انصراف</span>
                            </div>
                            <input type="hidden" id="tracking_code" value="<?= $tracking_code ?>">
                            <input type="hidden" id="price_total" value="<?= $price_total ?>">
                        </form>
                    </div>
                </div>
                <div id="wallet-info"></div>
            </div>
            <div class="col-12 col-md-6">
                <div class="desc-gateway-before">
                    <div class="desc-gateway">
                        <h4 class="title-gateway">توضیحات</h4>
                        <ul>
                            <li>کاربر گرامی، در صورتی که رمز دوم بیش از 3بار اشتباه وارد شود، کیف پول شما برای 24 ساعت غیر قابل استفاده خواهد شد.</li>
                            <li>لطفا توجه داشته باشید <br> مهلت پرداخت مابه‌التفاوت نقدی سفارش تنها 24 ساعت پس از پرداخت به وسیله کیف پول است و در غیر این صورت سفارش شما لغو و مبلغ به کیف پول شما عودت داده خواهد شد.</li>
                            <li>جهت پرداخت مابه‌التفاوت می‌تواند از بخش حساب کاربری/ سفارشات/ پرداخت مابه‌التفاوت اقدام نمائید.</li>
                        </ul>
                    </div>
                    <div class="info-marchent mt-5">
                        <h4 class="title-gateway">اطلاعات پذیرنده</h4>
                        <div class="inner-info-marchent mt-4">
                            <span class="title-info-marchent">نام فروشگاه:</span>
                            <span class="value-info-marchent"><?= $merchant_name ?></span>
                        </div>
                        <div class="inner-info-marchent mt-3">
                            <span class="title-info-marchent">شماره پذیرنده:</span>
                            <span class="value-info-marchent"><?= $merchant_national_id ?></span>
                        </div>
                        <div class="inner-info-marchent mt-3">
                            <span class="title-info-marchent">دسته بندی پذیرنده:</span>
                            <span class="value-info-marchent"><?= $cat ?></span>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php wp_footer(); ?>
</body>

</html>
