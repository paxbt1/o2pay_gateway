<?php

// تعریف اکشن‌های ایجکس برای کاربران واردشده و مهمان
add_action('wp_ajax_send_otp_second_code', 'send_otp_second_code');
add_action('wp_ajax_nopriv_send_otp_second_code', 'send_otp_second_code');

function send_otp_second_code() {
    // بررسی درخواست
    if (!isset($_POST['national_id']) || empty($_POST['amount_pay']) || empty($_POST['order_id'])) {
        wp_send_json_error(['message' => 'اطلاعات ارسالی ناقص است.']);
    }

    $national_id = isset($_POST['national_id']) ? sanitize_text_field($_POST['national_id']) : null;
    $order_total = isset($_POST['amount_pay']) ? sanitize_text_field($_POST['amount_pay']) : null;
    $order_id = isset($_POST['order_id']) ? sanitize_text_field($_POST['order_id']) : null;
    $tracking_code = isset($_POST['tracking_code']) ? sanitize_text_field($_POST['tracking_code']) : null;

    $order = wc_get_order($order_id);
        
    if (!$order) {
        wp_send_json_error(__('سفارش معتبر نیست.', 'woocommerce'), 'error');
        return;
    }

    // اطلاعات درگاه
    $o2pay_gateway = get_option('woocommerce_o2pay_gateway_settings');
    $api_key = $o2pay_gateway['api_key'];
    $api_secret = $o2pay_gateway['api_secret'];
    $order_total = $order->get_total();

    if (empty($api_key) || empty($api_secret)) {
        wp_send_json_error(__('پیکربندی درگاه پرداخت انجام نشده است.', 'woocommerce'), 'error');
        return;
    }

    // تولید توکن
    $date = strtotime(current_time('mysql'));
    $algo = 'sha256';
    $key_data = $order_id . $api_key . $order_total . $national_id . $date;
    $token = hash_hmac($algo, $key_data, $api_secret);

    // داده‌های ارسال به API
    $data = [
        'merchant_id' => $api_key,
        'token' => $token,
        'order_id' => $order_id,
        'credit_amount' => $order_total,
        'national_id' => $national_id,
        'date' => $date,
        'tracking_code' => $tracking_code,
    ];

    // مقداردهی cURL
    $ch = curl_init();

    // تنظیمات cURL
    curl_setopt($ch, CURLOPT_URL, 'https://test.o2pay.app/wp-json/webservice/v1/pay-request/');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // برای دریافت پاسخ
    curl_setopt($ch, CURLOPT_POST, true); // ارسال درخواست POST
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data)); // داده‌های ارسال به صورت JSON
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
    ]); // هدرهای مورد نیاز

    // ارسال درخواست و دریافت پاسخ
    $response = curl_exec($ch);

    error_log('Raw Response: ' . print_r($response, true));
    // بررسی خطاها
    if (curl_errno($ch)) {
        $error_msg = curl_error($ch);
        curl_close($ch);
        error_log('cURL Error: ' . $error_msg);
        wp_send_json_error(__('خطا در ارتباط با سرور: ' . $error_msg, 'woocommerce'), 'error');
        return;
    }
    // بستن اتصال cURL
    curl_close($ch);

    // تبدیل پاسخ JSON به آرایه PHP
    if (is_string($response) && is_array(json_decode($response, true)) && (json_last_error() === JSON_ERROR_NONE)) {
        $body = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('JSON Decode Error: ' . json_last_error_msg());
            wp_send_json_error(__('خطا در پردازش پاسخ سرور: ' . json_last_error_msg(), 'woocommerce'), 'error');
            return;
        }
    } else {
        error_log('Invalid JSON Response: ' . $response);
        wp_send_json_error(__('پاسخ سرور معتبر نیست.' . $response, 'woocommerce'), 'error');
        return;
    }

    // بررسی موفقیت‌آمیز بودن پاسخ
    if ( $body['success'] === true) {
        wp_send_json_success([
            'message' => $body['data']['message'],
        ], 200);
    } else {
        $error_message = $body['data']['message'] ?? 'خطای نامشخص';
        wp_send_json_error(__('خطا: ' . $error_message, 'woocommerce'), 'error');
        return;
    }
}


// تعریف اکشن‌های ایجکس برای کاربران واردشده و مهمان
add_action('wp_ajax_resend_otp_second_code', 'resend_otp_second_code');
add_action('wp_ajax_nopriv_resend_otp_second_code', 'resend_otp_second_code');

function resend_otp_second_code(){
    // بررسی درخواست
    if (!isset($_POST['national_id']) || empty($_POST['tracking_code'])) {
        wp_send_json_error(['message' => 'اطلاعات ارسالی ناقص است.']);
    }

    $national_id = isset($_POST['national_id']) ? sanitize_text_field($_POST['national_id']) : null;
    $tracking_code = isset($_POST['tracking_code']) ? sanitize_text_field($_POST['tracking_code']) : null;

    // داده‌های ارسال به API
    $data = [
        'national_id' => $national_id,
        'tracking_code' => $tracking_code,
    ];

    // مقداردهی cURL
    $ch = curl_init();

    // تنظیمات cURL
    curl_setopt($ch, CURLOPT_URL, 'https://test.o2pay.app/wp-json/webservice/v1/pay-otp-resender/');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // برای دریافت پاسخ
    curl_setopt($ch, CURLOPT_POST, true); // ارسال درخواست POST
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data)); // داده‌های ارسال به صورت JSON
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
    ]); // هدرهای مورد نیاز

    // ارسال درخواست و دریافت پاسخ
    $response = curl_exec($ch);
    error_log('Raw Response: ' . print_r($response, true));
    // بررسی خطاها
    if (curl_errno($ch)) {
        $error_msg = curl_error($ch);
        curl_close($ch);
        error_log('cURL Error: ' . $error_msg);
        wp_send_json_error(__('خطا در ارتباط با سرور: ' . $error_msg, 'woocommerce'), 'error');
        return;
    }
    // بستن اتصال cURL
    curl_close($ch);

    // تبدیل پاسخ JSON به آرایه PHP
    if (is_string($response) && is_array(json_decode($response, true)) && (json_last_error() === JSON_ERROR_NONE)) {
        $body = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('JSON Decode Error: ' . json_last_error_msg());
            wp_send_json_error(__('خطا در پردازش پاسخ سرور: ' . json_last_error_msg(), 'woocommerce'), 'error');
            return;
        }
    } else {
        error_log('Invalid JSON Response: ' . $response);
        wp_send_json_error(__('پاسخ سرور معتبر نیست.' . $response, 'woocommerce'), 'error');
        return;
    }

    // بررسی موفقیت‌آمیز بودن پاسخ
    if ( $body['success'] === true) {
        wp_send_json_success([
            'message' => $body['data']['message'],
        ], 200);
    } else {
        $error_message = $body['data']['message'] ?? 'خطای نامشخص';
        wp_send_json_error(__('خطا: ' . $error_message, 'woocommerce'), 'error');
        return;
    }
}


// تعریف اکشن‌های ایجکس برای کاربران واردشده و مهمان
add_action('wp_ajax_submit_form_gateway', 'submit_form_gateway');
add_action('wp_ajax_nopriv_submit_form_gateway', 'submit_form_gateway');

function submit_form_gateway(){

    // بررسی درخواست
    if (empty($_POST['tracking_code']) || empty($_POST['otp_sended_code']) || empty($_POST['order_id']) || empty($_POST['amount_pay']) || empty($_POST['national_id'])) {
        wp_send_json_error(['message' => 'اطلاعات ارسالی ناقص است.']);
    }

    $tracking_code = sanitize_text_field($_POST['tracking_code']);
    $otp_sended_code = sanitize_text_field($_POST['otp_sended_code']);
    $order_id = sanitize_text_field($_POST['order_id']);
    $credit_amount = sanitize_text_field($_POST['amount_pay']);
    $national_id = sanitize_text_field($_POST['national_id']);

    update_post_meta($order_id, '_wallet_payment_price', $credit_amount);
    
    // دریافت واحد پولی ووکامرس
    $currency = get_option('woocommerce_currency');

    // بررسی اینکه واحد پولی تومان است یا خیر
    if ($currency === 'IRT') { // IRT نشان‌دهنده تومان ایران در ووکامرس است
        $credit_amount = $credit_amount * 10; // تبدیل تومان به ریال
    }

    // اطلاعات درگاه
    $o2pay_gateway = get_option('woocommerce_o2pay_gateway_settings');
    $merchant_id = $o2pay_gateway['api_key'];
    $merchant_key = $o2pay_gateway['api_secret'];

    if (empty($merchant_id) || empty($merchant_key)) {
        wp_send_json_error(__('پیکربندی درگاه پرداخت انجام نشده است.', 'woocommerce'), 'error');
        return;
    }

    // تولید توکن
    $date = strtotime(current_time('mysql'));
    $algo = 'sha256';
    $key_data = $order_id . $merchant_id . $credit_amount . $national_id . $date;
    $token = hash_hmac($algo, $key_data, $merchant_key);

    // داده‌های ارسال به API کیف پول
    $data = [
        'merchant_id' => $merchant_id,
        'tracking_code' => $tracking_code,
        'otp_code' => $otp_sended_code,
        'order_id' => $order_id,
        'credit_amount' => $credit_amount,
        'date' => $date,
        'national_id' => $national_id,
        'token' => $token,
    ];

    // مقداردهی cURL برای درخواست به کیف پول
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://test.o2pay.app/wp-json/webservice/v1/pay-otp-verify/');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // برای دریافت پاسخ
    curl_setopt($ch, CURLOPT_POST, true); // ارسال درخواست POST
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data)); // داده‌های ارسال به صورت JSON
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
    ]); // هدرهای مورد نیاز

    // ارسال درخواست و دریافت پاسخ
    $response = curl_exec($ch);

    error_log('Raw Response: ' . print_r($response, true));
    if (curl_errno($ch)) {
        $error_msg = curl_error($ch);
        curl_close($ch);
        error_log('cURL Error: ' . $error_msg);
        wp_send_json_error(__('خطا در ارتباط با سرور: ' . $error_msg, 'woocommerce'), 'error');
        return;
    }
    curl_close($ch);

    // تبدیل پاسخ JSON به آرایه PHP
    if (is_string($response) && is_array(json_decode($response, true)) && (json_last_error() === JSON_ERROR_NONE)) {
        $body = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('JSON Decode Error: ' . json_last_error_msg());
            wp_send_json_error(__('خطا در پردازش پاسخ سرور: ' . json_last_error_msg(), 'woocommerce'), 'error');
            return;
        }
    } else {
        error_log('Invalid JSON Response: ' . $response);
        wp_send_json_error(__('پاسخ سرور معتبر نیست.' . $response, 'woocommerce'), 'error');
        return;
    }

    if ($body['success'] === true) {
        $result = Gateway_Difference_Handler::handle_difference($order_id, $credit_amount);

        if ($result['success']) {
            $order = wc_get_order($order_id);
            // ثبت پرداخت و انجام عملیات مربوطه
            $order->payment_complete();
    
            // اطمینان از تغییر وضعیت به "پردازش"
            $order->update_status('processing', 'پرداخت مابه‌التفاوت با موفقیت انجام شد.');
    
            // خالی کردن سبد خرید
            WC()->cart->empty_cart();
    
            // ارسال پاسخ موفقیت
            wp_send_json_success([
                'message' => 'پرداخت با موفقیت انجام شد.',
                'callback' => $result['callback'],
            ]);
        } else {
            wp_send_json_error(['message' => $result['message']]);
        }
        
    } else {
        $error_message = $body['data']['message'] ?? 'خطای نامشخص';
        wp_send_json_error(__('خطا: ' . $error_message, 'woocommerce'), 'error');
        return;
    }
    
}